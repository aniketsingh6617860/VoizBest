import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-corporatelogin',
  templateUrl: './corporatelogin.component.html',
  styleUrls: ['./corporatelogin.component.css']
})
export class CorporateloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
