import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prepaid',
  templateUrl: './prepaid.component.html',
  styleUrls: ['./prepaid.component.css']
})
export class PrepaidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
