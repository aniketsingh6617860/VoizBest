import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postpaid',
  templateUrl: './postpaid.component.html',
  styleUrls: ['./postpaid.component.css']
})
export class PostpaidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
