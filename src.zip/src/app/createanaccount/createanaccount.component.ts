import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createanaccount',
  templateUrl: './createanaccount.component.html',
  styleUrls: ['./createanaccount.component.css']
})
export class CreateanaccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
